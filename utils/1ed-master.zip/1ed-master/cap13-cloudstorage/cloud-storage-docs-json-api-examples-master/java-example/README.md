Java Sample
============

Source code:

- [src/main/java/StorageSample.java](https://github.com/GoogleCloudPlatform/cloud-storage-docs-json-api-examples/blob/master/java-example/src/main/java/StorageSample.java) - lists objects in a bucket.

For more information details about running this sample, including how to create the src/main/resources/client_secrets.json file, see
https://developers.google.com/storage/docs/json_api/v1/json-api-java-samples.
