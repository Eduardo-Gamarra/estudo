package br.com.livrowebservices.carros.domain.event;

/**
 * Created by rlech on 10/5/2015.
 */
public class BusEvent {
    public static class FavoritosEvent {
    }
    public static class NovoCarroEvent {
    }
}
